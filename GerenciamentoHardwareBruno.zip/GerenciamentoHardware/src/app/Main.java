package app;

import model.DAO.LaboratoriosDAO;
import model.DAO.MaquinaDAO;
import model.DAO.UsuariosDAO;
import model.DTO.Laboratorios;
import model.DTO.Maquina;
import model.DTO.Usuarios;

public class Main {

    public static void main(String[] args) {
        
        LaboratoriosDAO laboratorioDAO = new LaboratoriosDAO();

        
        Laboratorios laboratorios = new Laboratorios("Laboratório A", "Sala 101");
        laboratorioDAO.inserirLaboratorio(laboratorios);

        
        System.out.println("Laboratórios:");
        for (Laboratorios lab : laboratorioDAO.listarLaboratorios()) {
            System.out.println(lab);
        }

       
        MaquinaDAO maquinaDAO = new MaquinaDAO();

        
        Maquina maquina = new Maquina("ABC123", "Intel i7", "16GB", "512GB SSD",
                "2023-01-15", "Sala 101", "Ativa", 1);
        maquinaDAO.inserirMaquina(maquina);

        
        System.out.println("Máquinas:");
        for (Maquina m : maquinaDAO.listarMaquinas()) {
            System.out.println(m);
        }

        
        UsuariosDAO usuarioDAO = new UsuariosDAO();

        
        Usuarios usuario = new Usuarios("Carlos Silva", "carlos.silva@example.com", "senha123");
        usuarioDAO.inserirUsuario(usuario);

        
        System.out.println("Usuários:");
        for (Usuarios u : usuarioDAO.listarUsuarios()) {
            System.out.println(u);
        }
    }
}
